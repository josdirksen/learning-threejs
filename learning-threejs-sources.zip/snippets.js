// for debug purposes we add an Axis helper that renders
// the X,Y and Z axes.
var axes = new THREE.AxisHelper( 20 );
scene.add(axes);